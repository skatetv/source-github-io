import 'package:aqua_workout_pro/core.dart';
import 'package:flutter/material.dart';

class ProfileView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kThirdColor,
      body: Center(
        child: Text("Coming Soon :)"),
      ),
    );
  }
}
