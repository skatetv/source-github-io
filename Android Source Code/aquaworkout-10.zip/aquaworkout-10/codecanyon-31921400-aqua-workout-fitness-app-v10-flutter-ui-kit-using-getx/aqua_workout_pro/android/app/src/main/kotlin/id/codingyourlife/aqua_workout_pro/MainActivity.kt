package id.codingyourlife.aqua_workout_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
